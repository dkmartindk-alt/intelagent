package com.gui.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuiMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
