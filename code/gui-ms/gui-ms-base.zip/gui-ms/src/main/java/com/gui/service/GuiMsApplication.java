package com.gui.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuiMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuiMsApplication.class, args);
	}

}
