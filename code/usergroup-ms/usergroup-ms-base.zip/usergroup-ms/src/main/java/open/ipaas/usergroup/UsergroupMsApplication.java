package open.ipaas.usergroup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsergroupMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsergroupMsApplication.class, args);
	}

}
