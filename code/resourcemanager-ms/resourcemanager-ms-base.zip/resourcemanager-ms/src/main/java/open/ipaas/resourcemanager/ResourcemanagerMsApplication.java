package open.ipaas.resourcemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResourcemanagerMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourcemanagerMsApplication.class, args);
	}

}
