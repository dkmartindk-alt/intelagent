package open.ipaas.resourceaccesscontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResourceaccesscontrolMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceaccesscontrolMsApplication.class, args);
	}

}
